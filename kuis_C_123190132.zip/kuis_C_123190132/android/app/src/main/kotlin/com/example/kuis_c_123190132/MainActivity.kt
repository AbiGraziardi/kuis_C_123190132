package com.example.kuis_c_123190132

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
