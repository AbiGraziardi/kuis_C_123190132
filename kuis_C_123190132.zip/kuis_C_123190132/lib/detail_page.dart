import 'package:flutter/material.dart';
import 'data_movie.dart';

class DetailPage extends StatelessWidget {
  final DataMovie dataMovie;

  DetailPage({Key? key, required this.dataMovie}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(dataMovie.title),
      ),
      body: Container(
        child: _movieView(),
      ),
    );
  }

  Widget _movieView() {
    return SafeArea(
      child: Scaffold(
      body: Column(
        children: [
          poster(),
          title(),
        ],
      ),
    ),
    );
  }

  Widget poster() {
    return Container(
      child: Center(
        child: Column(
            children:[
        Padding(
        padding: EdgeInsets.fromLTRB(0, 50, 0, 10),
        child: Image.network(dataMovie.poster_path, width: 200,),
      ),
      ],
      ),
      ),
    );
  }

  Widget title() {
    return Container(
      child: Text(
        dataMovie.title,
        style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
      ),
    );
  }


}
