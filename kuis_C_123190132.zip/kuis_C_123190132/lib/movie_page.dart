import 'package:flutter/material.dart';
import 'data_movie.dart';
import 'detail_page.dart';

class MoviePage extends StatelessWidget {
  var dataMovie = getDataMovie;

  MoviePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Movie'),
      ),
      body: Container(
        child: _gridView(),
      ),
    );
  }

  Widget _gridView() {
    return GridView.builder(
      gridDelegate:
      SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
      itemBuilder: (context, index) {
        return _movieCard(dataMovie[index], context);
      },
      itemCount: dataMovie.length,
    );
  }

  Widget _movieCard(DataMovie dataMovie, BuildContext context){
    return Card(
      child: InkWell(
        onTap: (){
          Navigator.push(context, MaterialPageRoute(builder: (context){
            return DetailPage(dataMovie: dataMovie);
          }));
        },
        child: Container(
          padding: EdgeInsets.all(15),
          child: Column(children: [
            Expanded(
              flex: 3,
              child: Image.network(dataMovie.poster_path, width: 300,),
            ),
            Expanded(
                flex: 1,
                child: Column(
                  children: [
                    Text(
                      dataMovie.title,
                      style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      'Release date: ${dataMovie.release_date}',
                      style: TextStyle(fontSize: 13),
                    ),
                    Text(
                      'Popularity: ${dataMovie.popularity}',
                      style: TextStyle(fontSize: 13, color: Colors.blue, fontWeight: FontWeight.bold),
                    ),
                  ],
                )
            ),
          ]),
        ),
      ),
    );
  }

}
